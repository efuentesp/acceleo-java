# SADF

A continuaci�n se describen los pasos para ejecutar/editar la aplicaci�n.

1. Se descarga
2. Se importa en un ambiente Eclipse Neon 3.0
3. La versi�n de Java utilizada es 8.5