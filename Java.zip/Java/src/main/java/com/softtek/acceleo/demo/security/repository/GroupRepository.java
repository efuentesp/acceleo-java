package com.softtek.acceleo.demo.security.repository;

import com.softtek.acceleo.demo.domain.Grupo;

public interface GroupRepository {

	 public Grupo getGroup(int groupId);   
	
}
