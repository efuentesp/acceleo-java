package com.softtek.acceleo.demo.security;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Clock;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.DefaultClock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.softtek.acceleo.demo.domain.Authority;
import com.softtek.acceleo.demo.domain.User;

@Component
public class JwtTokenUtil implements Serializable {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	static final String CLAIM_KEY_USERNAME = "sub";
	static final String CLAIM_KEY_CREATED = "iat";
	private static final long serialVersionUID = -3301605591108950415L;
	private final int CERO = 0;

	private Clock clock = DefaultClock.INSTANCE;

	@Value("${jwt.secret}")
	private String secret;

	@Value("${jwt.expiration}")
	private Long expiration;

	public String getUsernameFromToken(String token) {

		logger.info("On GetUsernameFromToken secret :" + secret);

		return getClaimFromToken(token, Claims::getSubject);
	}

	public Date getIssuedAtDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getIssuedAt);
	}

	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}
	
	public String getRoleFromToken(String token) {
		Claims claims = getAllClaimsFromToken(token);
		Object role = claims.get("role");
		
		return role.toString();
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}

	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
	}

	private Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);

		logger.debug("******************* EXPIRATION : " + expiration);

		logger.debug("******************* CLOCK : " + clock.now());
		return expiration.before(clock.now());
	}

	private Boolean isCreatedBeforeLastPasswordReset(Date created, Date lastPasswordReset) {
		return (lastPasswordReset != null && created.before(lastPasswordReset));
	}

	private Boolean ignoreTokenExpiration(String token) {
		// here you specify tokens, for that the expiration is ignored
		return false;
	}

	//public String generateToken(UserDetails userDetails) {
	public String generateToken(User user) {
		Map<String, Object> claims = new HashMap<>();
		
		claims.put("username", user.getUserName());
		claims.put("display_name", user.getFirstname() + " " + user.getLastname());
		claims.put("email", user.getEmail());
		claims.put("user_enabled", user.getEnabled());
		
		if( user.getAuthorities().isEmpty() ) {
			logger.info("El user no tiene asociado roles (authority's)");
		}else {
			Authority authority = user.getAuthorities().get(CERO);

			claims.put("role", authority.getName());
			claims.put("role_enabled", authority.getEnabled());			
		}	
		
		//return doGenerateToken(claims, userDetails.getUsername());
		return doGenerateToken(claims, user.getUserName());
	}

	private String doGenerateToken(Map<String, Object> claims, String subject) {
		final Date createdDate = clock.now();
		final Date expirationDate = calculateExpirationDate(createdDate);

		logger.info("********** Fecha  :" + new Date());
		logger.info("********** createDate clock now :" + createdDate);
		logger.info("********** EXPIRATIONDATE :" + expirationDate);

		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(createdDate)
				.setExpiration(expirationDate).signWith(SignatureAlgorithm.HS512, secret).compact();
	}

	public Boolean canTokenBeRefreshed(String token, Date lastPasswordReset) {
		final Date created = getIssuedAtDateFromToken(token);
		return !isCreatedBeforeLastPasswordReset(created, lastPasswordReset)
				&& (!isTokenExpired(token) || ignoreTokenExpiration(token));
	}

	public String refreshToken(String token) {
		final Date createdDate = clock.now();
		final Date expirationDate = calculateExpirationDate(createdDate);

		final Claims claims = getAllClaimsFromToken(token);
		claims.setIssuedAt(createdDate);
		claims.setExpiration(expirationDate);

		return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS512, secret).compact();
	}

	public Boolean validateToken(String token, UserDetails userDetails) {
		JwtUser user = (JwtUser) userDetails;
		final String username = getUsernameFromToken(token);
		final Date created = getIssuedAtDateFromToken(token);
		// final Date expiration = getExpirationDateFromToken(token);

		logger.debug("validateToken ");
		return (username.equals(user.getUsername()) && !isTokenExpired(token)
				&& !isCreatedBeforeLastPasswordReset(created, user.getLastPasswordResetDate()));
	}

	private Date calculateExpirationDate(Date createdDate) {

		logger.info("********************** createDate" + createdDate);
		logger.info("********************** expiration" + expiration);

		Date ejemplo = new Date(createdDate.getTime() + expiration * 1000);
		logger.info("********************** calculada" + ejemplo);
		return new Date(createdDate.getTime() + expiration * 1000);
	}
}
