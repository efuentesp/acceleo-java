package com.softtek.acceleo.demo.security;

public interface PasswordEncoder {

}
